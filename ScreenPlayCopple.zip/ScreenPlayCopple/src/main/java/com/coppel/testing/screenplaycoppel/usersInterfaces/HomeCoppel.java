package com.coppel.testing.screenplaycoppel.usersInterfaces;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;

@DefaultUrl("https://www.coppel.com")
//se hereda el pageobject para la clase homecoppel, retorne
public class HomeCoppel extends PageObject{

}
